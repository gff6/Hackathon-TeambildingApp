# sidequest – frontend (Today/profile, Party feed, Leaderboard, Rewards)

This frontend follows the team's *side quest* design. It has a white sidebar, a lavender background and purple buttons. The level card is dark plum with a lime XP bar.

It is plain HTML, CSS and JavaScript. There are no frameworks, nothing to install and no build step.
Open `index.html` in a browser and it works.

## Files

| File | What it does |
|------|--------------|
| `index.html` | The page skeleton: a sidebar with 4 links and 4 `<section>`s (one per view). JavaScript fills in most of the content. |
| `style.css` | All the styling. The colours are variables at the top (`:root`). |
| `data.js` | Example data: the user, today's quests, outfits/badges, hair colours, teammates, shared quests and feed posts. |
| `app.js` | The logic, in 6 numbered parts: saving, level maths, helpers, render functions, actions, navigation. |

`data.js` must load before `app.js`. `index.html` already loads them in that order.

## The four views

1. **Today (user profile):** the level card with an XP bar, your streak and how much XP you need for your next unlock.
   - *Today's quests:* click a quest to finish it. Open quests show their deadline and what happens if you miss it.
   - *＋ New quest:* opens a small form. The quest's XP is 2 × its minutes.
   - *Your character:* has Outfit / Hair / Extras tabs (glasses, backpack).
   - *Your study party:* the top 3 this week.
   - *HP card:* shows your cheat days and a "Use day" button. Every 5 finished quests earn 1 cheat day.
2. **Party (team newsfeed):** stat tiles and filters (All / Needs rating / Created by me) for shared quest cards.
   - The *Rate a quest* panel has 1–5 scores and a feedback box.
   - The party feed lists what everyone did.
   - The dark card shows creator coins, cheat days and the crew's XP for the week.
3. **Leaderboard:** a "This week / All time" switch, numbered rows with "You" highlighted, and a hint like "Just X XP from place N".
4. **Rewards:** outfits and badges that unlock by level, plus a large preview of your character.

## How it works

- **One rule: change the data, then call `render()`.** Every `renderX()` function rebuilds its part of the page from the data.
- **Levels:** only XP is stored. `getLevelInfo(xp)` works out the level. Each level needs 50 XP more than the one before (100, 150, 200 …).
- **Character:** `characterSVG(color, size)` draws it with a few SVG shapes, so there are no image files. An outfit is just a hoodie colour.
- **Saving:** a few small values go into `localStorage`. To reset before the demo, run `localStorage.clear()` in the browser console and reload. Quests you add with "New quest" are not saved after a reload.

## Adding things

- **A new quest, outfit, badge, hair colour, teammate or shared quest:** add one line to the matching array in `data.js`.
- **A new view:** add a sidebar button and a `<section class="view">` in `index.html`. Then write a `renderSomething()` in `app.js` and call it from `render()`.

## Uploading to GitHub (no command line needed)

1. Open your repository on github.com.
2. Click **Add file → Upload files**.
3. Drag in `index.html`, `style.css`, `data.js`, `app.js` and `README.md`. Put them in a folder such as `frontend/` if your team wants that.
4. Write a short message, for example "Add profile, party, leaderboard and rewards views", and click **Commit changes**.

To show the app online for the demo, go to **Settings → Pages** and choose the branch. GitHub Pages then gives you a link.

## Plugging in a backend later

At the moment the data is written directly into `data.js`. When your backend has an API, load the data with `fetch` instead and keep everything else:

```js
// at the bottom of app.js, instead of loadUser(); render();
async function start() {
  const res = await fetch("/api/me");          // example URL
  Object.assign(currentUser, await res.json());
  // same idea for teammates, sharedQuests, feed ...
  render();
}
start();
```

In `completeTask()`, `submitRating()` and `equipSkin()`, send the change to the server with `fetch(..., { method: "POST" })` instead of calling `saveUser()`.
