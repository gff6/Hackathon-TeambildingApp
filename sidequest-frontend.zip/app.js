/* =========================================================
   app.js  –  all the logic
   ---------------------------------------------------------
   1. Saving / loading (localStorage)
   2. Level maths
   3. Helpers (character drawing, avatars, ranking)
   4. Render functions (one per view)
   5. Actions (finish/add quests, customise character, rate, cheat day)
   6. Navigation + start-up
   ========================================================= */


/* ---------- 1. SAVING / LOADING ----------
   We only store a few small values, so localStorage is fine.
   If storage is blocked, the try/catch means progress just isn't saved. */
const SAVE_KEY = "sidequest-user";

function loadUser() {
  try {
    const saved = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (saved) Object.assign(currentUser, saved);
  } catch (e) { /* ignore */ }
}

function saveUser() {
  try {
    const { xp, weekXp, equippedSkin, hair, extras, doneTasks, cheatDays, commitments } = currentUser;
    localStorage.setItem(SAVE_KEY, JSON.stringify({ xp, weekXp, equippedSkin, hair, extras, doneTasks, cheatDays, commitments }));
  } catch (e) { /* ignore */ }
}


/* ---------- 2. LEVEL MATHS ----------
   MMO style: each level needs a bit more XP than the last.
   Level 1 -> 2 needs 100 XP, 2 -> 3 needs 150, 3 -> 4 needs 200 ...  */
function xpForNextLevel(level) {
  return 50 + level * 50;
}

// Turns total XP into { level, xpIntoLevel, xpNeeded }
function getLevelInfo(totalXp) {
  let level = 1;
  let xpLeft = totalXp;
  while (xpLeft >= xpForNextLevel(level)) {
    xpLeft -= xpForNextLevel(level);
    level++;
  }
  return { level: level, xpIntoLevel: xpLeft, xpNeeded: xpForNextLevel(level) };
}

// Total XP you need to *reach* a level (used for "XP to next unlock")
function totalXpForLevel(level) {
  let total = 0;
  for (let l = 1; l < level; l++) total += xpForNextLevel(l);
  return total;
}

function myLevel() {
  return getLevelInfo(currentUser.xp).level;
}


/* ---------- 3. HELPERS ---------- */

function getSkin(id) {
  return rewards.find(r => r.id === id) || rewards[0];
}

// A tiny cartoon student drawn with SVG shapes (no image files needed).
// outfitColor = hoodie colour. Hair, glasses and backpack come from the user.
function characterSVG(outfitColor, size) {
  const hair = hairColors[currentUser.hair];
  const { glasses, backpack } = currentUser.extras;
  return `
  <svg width="${size}" height="${size * 1.4}" viewBox="0 0 100 140">
    ${backpack ? `<rect x="74" y="54" width="22" height="38" rx="8" fill="#8a6d3b" stroke="#2b2340" stroke-width="2"/>` : ""}
    <rect x="34" y="96" width="13" height="34" rx="5" fill="#2b2340"/>
    <rect x="53" y="96" width="13" height="34" rx="5" fill="#2b2340"/>
    <rect x="28" y="126" width="21" height="9" rx="4" fill="#fff" stroke="#2b2340" stroke-width="2"/>
    <rect x="51" y="126" width="21" height="9" rx="4" fill="#fff" stroke="#2b2340" stroke-width="2"/>
    <rect x="24" y="52" width="52" height="50" rx="16" fill="${outfitColor}" stroke="#2b2340" stroke-width="2"/>
    <rect x="14" y="56" width="14" height="38" rx="7" fill="${outfitColor}" stroke="#2b2340" stroke-width="2"/>
    <rect x="72" y="56" width="14" height="38" rx="7" fill="${outfitColor}" stroke="#2b2340" stroke-width="2"/>
    ${backpack ? `<path d="M36 54 L70 90" stroke="#5c4524" stroke-width="5"/>` : ""}
    <circle cx="50" cy="34" r="20" fill="#c98a5e" stroke="#2b2340" stroke-width="2"/>
    <path d="M30 30 Q32 8 52 10 Q72 10 70 30 Q62 20 50 22 Q38 20 30 30Z" fill="${hair}" stroke="#2b2340" stroke-width="1.5"/>
    ${glasses
      ? `<circle cx="43" cy="35" r="5" fill="none" stroke="#2b2340" stroke-width="2"/>
         <circle cx="57" cy="35" r="5" fill="none" stroke="#2b2340" stroke-width="2"/>`
      : `<circle cx="43" cy="35" r="2" fill="#2b2340"/><circle cx="57" cy="35" r="2" fill="#2b2340"/>`}
    <path d="M45 45 Q50 49 55 45" fill="none" stroke="#2b2340" stroke-width="2" stroke-linecap="round"/>
  </svg>`;
}

// Round avatar with initials, coloured by the person's outfit
function avatarHTML(name, skinId) {
  const initials = name.split(" ").map(word => word[0]).join("").slice(0, 2);
  return `<div class="avatar" style="background:${getSkin(skinId).color}">${initials}</div>`;
}

// Find a person's outfit by name (works for you and teammates)
function skinOf(name) {
  if (name === currentUser.name) return currentUser.equippedSkin;
  const mate = teammates.find(t => t.name === name);
  return mate ? mate.skin : "violet";
}

// Everyone (you + teammates) sorted by "weekXp" or "xp"
function getRanking(key) {
  const me = { id: currentUser.id, name: currentUser.name, xp: currentUser.xp,
               weekXp: currentUser.weekXp, skin: currentUser.equippedSkin };
  return teammates.concat(me).sort((a, b) => b[key] - a[key]);
}

// One leaderboard row (used by the full leaderboard and the mini one)
function rankRowHTML(person, index, key) {
  const isMe = person.id === currentUser.id;
  return `
    <li class="${isMe ? "me" : ""}">
      <span class="rank">${String(index + 1).padStart(2, "0")}</span>
      ${avatarHTML(person.name, person.skin)}
      <span class="lb-name">${isMe ? "You" : person.name}
        <span class="muted small">· Lv ${getLevelInfo(person.xp).level}</span></span>
      <span class="lb-xp">${person[key].toLocaleString()} XP</span>
    </li>`;
}

// "Just 31 XP from place 2" style motivation text
function gapHint(ranking, key) {
  const i = ranking.findIndex(p => p.id === currentUser.id);
  if (i === 0) return "📈 You're in first place. Keep it up!";
  const gap = ranking[i - 1][key] - currentUser[key] + 1;
  return `📈 Just ${gap} XP from place ${i}. You've got this.`;
}

function questsNeedingRating() {
  return sharedQuests.filter(q => q.status === "needs-rating" && q.creator !== currentUser.name);
}


/* ---------- 4. RENDER FUNCTIONS ----------
   Each function reads the data and rewrites its part of the page.
   Simple rule: change the data, then call render(). */

function renderSidebar() {
  document.getElementById("sidebar-name").textContent = currentUser.name;
  document.getElementById("sidebar-title").textContent = `${currentUser.title} · Level ${myLevel()}`;
  document.getElementById("crew-size").textContent = `${teammates.length + 1} members · Private`;
  const needs = questsNeedingRating().length;
  document.getElementById("party-badge").textContent = needs || "";   // empty = hidden
}

function renderProfile() {
  const info = getLevelInfo(currentUser.xp);
  const skin = getSkin(currentUser.equippedSkin);

  document.getElementById("greeting").textContent = `Ready, ${currentUser.name.split(" ")[0]}?`;
  document.getElementById("lvl-num").textContent = info.level;
  document.getElementById("hero-title").textContent = currentUser.title;
  document.getElementById("xp-text").textContent = `${info.xpIntoLevel} / ${info.xpNeeded} XP`;
  document.getElementById("next-level").textContent = `Level ${info.level + 1}`;
  document.getElementById("xp-fill").style.width = (info.xpIntoLevel / info.xpNeeded * 100) + "%";
  document.getElementById("streak").textContent = `🔥 ${currentUser.streakDays}-day streak`;

  // "XP to your next unlock": the next reward you don't have yet
  const nextReward = rewards
    .filter(r => r.unlockLevel > info.level)
    .sort((a, b) => a.unlockLevel - b.unlockLevel)[0];
  document.getElementById("next-unlock").textContent = nextReward
    ? `${totalXpForLevel(nextReward.unlockLevel) - currentUser.xp} XP to your next unlock`
    : "Everything unlocked!";

  // Today's quests (open ones show their deadline and penalty)
  const doneCount = tasks.filter(t => currentUser.doneTasks.includes(t.id)).length;
  document.getElementById("quest-count").textContent = `${doneCount} / ${tasks.length}`;
  document.getElementById("task-list").innerHTML = tasks.map(t => {
    const done = currentUser.doneTasks.includes(t.id);
    return `
      <div class="quest ${done ? "done" : ""}" onclick="completeTask('${t.id}')" title="Click to complete">
        <div class="check">${done ? "✓" : ""}</div>
        <div class="game-icon">${t.icon}</div>
        <div class="info">
          <b>${t.label}</b>
          <p class="muted">${t.game} · ${t.subject} · ${t.minutes} min${done ? " · Completed" : ""}</p>
        </div>
        <div class="xp">+${t.xp} XP<small>${t.difficulty}</small></div>
        ${done ? "" : `
        <div class="quest-foot">
          <span class="tag">${t.game} · ${t.subject}</span>
          <span class="deadline">Committed · ${t.deadline}</span>
          <p class="warn">${t.penalty}</p>
        </div>`}
      </div>`;
  }).join("");

  // Character + the options of the selected tab
  document.getElementById("profile-character").innerHTML = characterSVG(skin.color, 120);
  renderCharacterOptions();

  // Mini leaderboard: top 3 this week (plus you, if you're not in it)
  const ranking = getRanking("weekXp");
  const myIndex = ranking.findIndex(p => p.id === currentUser.id);
  let rows = ranking.slice(0, 3).map((p, i) => rankRowHTML(p, i, "weekXp")).join("");
  if (myIndex > 2) rows += rankRowHTML(ranking[myIndex], myIndex, "weekXp");
  document.getElementById("mini-board").innerHTML = rows;
  document.getElementById("mini-hint").textContent = gapHint(ranking, "weekXp");

  // Health, cheat days and commitments
  document.getElementById("hp-text").textContent = `${currentUser.hp} / 100 HP`;
  document.getElementById("cheat-text").textContent = `${currentUser.cheatDays} cheat day${currentUser.cheatDays === 1 ? "" : "s"} banked`;
  document.getElementById("hp-fill").style.width = currentUser.hp + "%";
  document.getElementById("commit-text").textContent =
    `${currentUser.commitments} / 5 commitments toward your next day`;
}

// "outfit", "hair" or "extras" – changed by the tabs on the character card
let charTab = "outfit";

function renderCharacterOptions() {
  let html = "";
  if (charTab === "outfit") {
    // Only outfits you have unlocked
    html = `<span class="muted">Outfit colour</span><div class="swatches">` +
      rewards.filter(r => r.type === "skin" && r.unlockLevel <= myLevel())
        .map(r => swatchHTML(r.color, r.id === currentUser.equippedSkin, `equipSkin('${r.id}')`, r.name))
        .join("") + `</div>`;
  } else if (charTab === "hair") {
    html = `<span class="muted">Hair colour</span><div class="swatches">` +
      Object.keys(hairColors)
        .map(h => swatchHTML(hairColors[h], h === currentUser.hair, `setHair('${h}')`, h))
        .join("") + `</div>`;
  } else {
    html = `<span class="muted">Extras</span><div class="swatches">` +
      ["glasses", "backpack"].map(x =>
        `<button class="chip ${currentUser.extras[x] ? "on" : ""}" onclick="toggleExtra('${x}')">${x}</button>`
      ).join("") + `</div>`;
  }
  document.getElementById("char-options").innerHTML = html;
}

function swatchHTML(color, selected, onclick, title) {
  return `<button class="swatch ${selected ? "selected" : ""}" style="background:${color}"
            title="${title}" onclick="${onclick}">${selected ? "✓" : ""}</button>`;
}

function renderRewards() {
  const level = myLevel();
  const skin = getSkin(currentUser.equippedSkin);

  // Builds one reward tile. Locked if your level is too low.
  function tile(r) {
    const locked = level < r.unlockLevel;
    const equipped = r.id === currentUser.equippedSkin;
    const classes = "reward" + (locked ? " locked" : "") + (equipped ? " equipped" : "");
    const click = (r.type === "skin" && !locked) ? `onclick="equipSkin('${r.id}')"` : "";
    const picture = r.type === "skin" ? characterSVG(r.color, 44) : r.icon;
    const label = locked ? `🔒 Level ${r.unlockLevel}` : (equipped ? "Equipped" : r.name);
    return `<div class="${classes}" ${click} title="${r.name}">
              <div class="icon">${picture}</div><p>${label}</p>
            </div>`;
  }

  document.getElementById("skin-grid").innerHTML =
    rewards.filter(r => r.type === "skin").map(tile).join("");
  document.getElementById("badge-grid").innerHTML =
    rewards.filter(r => r.type === "badge").map(tile).join("");

  document.getElementById("reward-character").innerHTML = characterSVG(skin.color, 120);
  document.getElementById("reward-skin-name").textContent = skin.name;
  const unlocked = rewards.filter(r => r.unlockLevel <= level).length;
  document.getElementById("unlock-count").textContent = `${unlocked} / ${rewards.length} unlocked`;
}

// "all", "needs" or "mine" – changed by the filter buttons on the Party page
let questFilter = "all";

function renderParty() {
  const needs = questsNeedingRating();
  const mine = sharedQuests.filter(q => q.creator === currentUser.name);

  document.getElementById("stat-shared").textContent = sharedQuests.length;
  document.getElementById("stat-needs").textContent = needs.length;

  // Filter buttons show their counts, e.g. "Needs rating (1)"
  const labels = { all: `All quests (${sharedQuests.length})`, needs: `Needs rating (${needs.length})`, mine: `Created by me (${mine.length})` };
  document.querySelectorAll(".filter-btn").forEach(b => b.textContent = labels[b.dataset.filter]);

  const shown = questFilter === "needs" ? needs : questFilter === "mine" ? mine : sharedQuests;
  document.getElementById("shared-list").innerHTML = shown.map(q => {
    const needsMe = needs.includes(q);
    return `
      <div class="shared ${needsMe ? "needs" : ""}">
        <div class="row-between">
          <span class="label">${needsMe ? "Needs your rating" : "Peer reviewed"}</span>
          <span class="xp">${q.xp ? "+" + q.xp + " XP" : "XP pending"}</span>
        </div>
        <h3>${q.icon} ${q.title}</h3>
        <p class="muted small">${q.game} · ${q.subject} · ${q.minutes} min · ${q.demand} · ${q.creator === currentUser.name ? "Created by you" : q.creator}</p>
        <p>${q.description}</p>
        <div class="row-between small">
          <span class="muted">${q.usefulness ? `Usefulness ${q.usefulness.toFixed(1)} / 5 · ` : ""}${q.ratings} of 2 peer ratings</span>
          ${needsMe ? `<button class="btn" onclick="selectForRating('${q.id}')">Rate this quest</button>` : ""}
        </div>
      </div>`;
  }).join("") || `<p class="muted">Nothing here yet.</p>`;

  renderRatePanel();

  // Feed
  const icons = { quest: "✅", level: "⬆️", unlock: "🎁", streak: "🔥", rating: "⭐", created: "📝" };
  document.getElementById("feed-list").innerHTML = feed.map(post => `
    <li>
      ${avatarHTML(post.user, skinOf(post.user))}
      <div class="feed-text">
        <b>${post.user}</b> ${post.text} ${icons[post.type] || ""}
        <small>${post.time}</small>
      </div>
      ${post.xp ? `<span class="pill purple">+${post.xp} XP</span>` : ""}
    </li>`).join("");

  // Dark card: coins, cheat days and party XP
  const partyXp = teammates.reduce((sum, t) => sum + t.weekXp, currentUser.weekXp);
  document.getElementById("coins-title").textContent =
    `${currentUser.coins} creator coins · ${currentUser.cheatDays} cheat day${currentUser.cheatDays === 1 ? "" : "s"}`;
  document.getElementById("party-xp").textContent =
    `Your crew earned ${partyXp.toLocaleString()} XP together this week.`;
}

// What you picked in the "Rate a quest" panel
const rating = { questId: null, difficulty: 0, usefulness: 0, feedback: "" };

function renderRatePanel() {
  const needs = questsNeedingRating();
  const panel = document.getElementById("rate-panel");

  if (needs.length === 0) {
    panel.innerHTML = `<h3>Rate a quest</h3><p class="muted">You're all caught up. 🎉</p>`;
    return;
  }
  // Default to the first quest that needs a rating
  if (!needs.find(q => q.id === rating.questId)) rating.questId = needs[0].id;
  const q = needs.find(q => q.id === rating.questId);

  // A row of 1–5 buttons for one question ("difficulty" or "usefulness")
  function scale(field, low, high) {
    const buttons = [1, 2, 3, 4, 5].map(n =>
      `<button class="${rating[field] === n ? "on" : ""}" onclick="setRating('${field}', ${n})">${n}</button>`
    ).join("");
    return `<div class="rate-scale">${buttons}</div>
            <div class="scale-labels"><span>${low}</span><span>${high}</span></div>`;
  }

  panel.innerHTML = `
    <div class="row-between"><h3>Rate a quest</h3><small class="tag">Your turn</small></div>
    <h2 style="color:var(--purple); margin:6px 0 10px">${q.title}</h2>
    <p class="muted small">Rate reasoning depth, accuracy and expected effort.</p>
    <div class="row-between"><b>Difficulty</b><b class="tag">${rating.difficulty || "–"} / 5</b></div>
    <p class="muted small">How much effort will this take?</p>
    ${scale("difficulty", "Very easy", "Very hard")}
    <div class="row-between"><b>Usefulness</b><b class="tag">${rating.usefulness || "–"} / 5</b></div>
    <p class="muted small">How valuable is this for your group?</p>
    ${scale("usefulness", "Not useful", "Very useful")}
    <b>Feedback (optional)</b>
    <div class="form"><textarea id="feedback" rows="3" placeholder="A practical example would help..."
      oninput="rating.feedback = this.value">${rating.feedback}</textarea></div>
    <button class="btn full" style="margin-top:12px" onclick="submitRating()">Submit rating</button>
    <p class="muted small">Team XP finalises after both peers rate it.</p>`;
}

// "week" or "all" – changed by the toggle buttons
let leaderboardPeriod = "week";

function renderLeaderboard() {
  const key = leaderboardPeriod === "week" ? "weekXp" : "xp";
  const ranking = getRanking(key);
  document.getElementById("leaderboard-list").innerHTML =
    ranking.map((p, i) => rankRowHTML(p, i, key)).join("");
  document.getElementById("lb-hint").textContent = gapHint(ranking, key);
}

// Redraw everything (it is tiny, so this is fast enough)
function render() {
  renderSidebar();
  renderProfile();
  renderRewards();
  renderParty();
  renderLeaderboard();
}


/* ---------- 5. ACTIONS ---------- */

function completeTask(taskId) {
  if (currentUser.doneTasks.includes(taskId)) return;  // already done

  const task = tasks.find(t => t.id === taskId);
  const levelBefore = myLevel();

  currentUser.xp += task.xp;
  currentUser.weekXp += task.xp;
  currentUser.doneTasks.push(taskId);
  addToFeed("quest", `finished ${task.label}`, task.xp);

  // Every 5 finished commitments earn a cheat day
  currentUser.commitments++;
  let message = `+${task.xp} XP`;
  if (currentUser.commitments >= 5) {
    currentUser.commitments = 0;
    currentUser.cheatDays++;
    message += " · +1 cheat day!";
  }

  const levelAfter = myLevel();
  if (levelAfter > levelBefore) {
    addToFeed("level", `reached Level ${levelAfter}`);
    message = `⬆️ Level up! You are now level ${levelAfter}`;
  }

  showToast(message);
  saveUser();
  render();
}

// "New quest" form: show/hide it (force = true always shows it)
function toggleQuestForm(force) {
  const form = document.getElementById("quest-form");
  form.classList.toggle("hidden", force ? false : !form.classList.contains("hidden"));
  if (!form.classList.contains("hidden")) document.getElementById("q-title").focus();
}

function addQuest(event) {
  event.preventDefault();   // stop the form from reloading the page
  const minutes = Number(document.getElementById("q-minutes").value);
  const quest = {
    id: "custom-" + Date.now(),
    label: document.getElementById("q-title").value,
    subject: document.getElementById("q-subject").value,
    icon: "📝", game: "Custom quest", minutes: minutes,
    xp: minutes * 2,                    // simple rule: 2 XP per minute
    difficulty: "Your quest", deadline: "Today, 23:59",
    penalty: "Missed deadline: −20 HP."
  };
  tasks.push(quest);   // note: custom quests are not saved after a reload
  addToFeed("created", `created the quest ${quest.label}`);
  event.target.reset();
  toggleQuestForm();
  showToast("Quest added to today");
  render();
}

function equipSkin(skinId) {
  currentUser.equippedSkin = skinId;
  saveUser();
  render();
  showToast(`Equipped ${getSkin(skinId).name}`);
}

function setHair(color) {
  currentUser.hair = color;
  saveUser();
  render();
}

function toggleExtra(name) {
  currentUser.extras[name] = !currentUser.extras[name];
  saveUser();
  render();
}

function useCheatDay() {
  if (currentUser.cheatDays === 0) {
    showToast("No cheat days left. Finish 5 commitments to earn one.");
    return;
  }
  currentUser.cheatDays--;
  saveUser();
  render();
  showToast("😴 Deadlines paused for 24 h");
}

// Rating panel
function selectForRating(questId) {
  rating.questId = questId;
  rating.difficulty = 0;
  rating.usefulness = 0;
  rating.feedback = "";
  renderRatePanel();
  document.getElementById("rate-panel").scrollIntoView({ behavior: "smooth" });
}

function setRating(field, value) {
  rating[field] = value;
  renderRatePanel();
}

function submitRating() {
  if (!rating.difficulty || !rating.usefulness) {
    showToast("Pick a difficulty and a usefulness score first");
    return;
  }
  const q = sharedQuests.find(q => q.id === rating.questId);
  q.ratings++;
  q.status = "reviewed";
  q.usefulness = rating.usefulness;
  q.xp = q.minutes * 2 + rating.difficulty * 10;   // simple XP estimate
  addToFeed("rating", `rated ${q.title}`);
  showToast("⭐ Rating sent. Thanks!");
  Object.assign(rating, { questId: null, difficulty: 0, usefulness: 0, feedback: "" });
  render();
}

// New posts go to the top. We keep max 20 so the list never grows forever.
function addToFeed(type, text, xp) {
  feed.unshift({ user: currentUser.name, type: type, text: text, xp: xp, time: "just now" });
  if (feed.length > 20) feed.pop();
}

let toastTimer;
function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2200);
}


/* ---------- 6. NAVIGATION + START-UP ---------- */

// Show one view (section) and highlight its sidebar button
function showView(viewId) {
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === viewId));
  document.querySelectorAll(".nav-link").forEach(b => b.classList.toggle("active", b.dataset.view === viewId));
  window.scrollTo(0, 0);
}

document.querySelectorAll(".nav-link").forEach(button => {
  button.addEventListener("click", () => showView(button.dataset.view));
});

// Helper for a group of buttons where only one can be active.
// onPick gets the clicked button so we can read its data-… value.
function setupButtonGroup(selector, onPick) {
  document.querySelectorAll(selector).forEach(button => {
    button.addEventListener("click", () => {
      document.querySelectorAll(selector).forEach(b => b.classList.remove("active"));
      button.classList.add("active");
      onPick(button);
    });
  });
}

setupButtonGroup(".period-btn", b => { leaderboardPeriod = b.dataset.period; renderLeaderboard(); });
setupButtonGroup(".filter-btn", b => { questFilter = b.dataset.filter; renderParty(); });
setupButtonGroup(".char-tab",   b => { charTab = b.dataset.tab; renderCharacterOptions(); });

loadUser();
render();
