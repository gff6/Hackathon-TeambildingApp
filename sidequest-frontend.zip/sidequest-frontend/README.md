# sidequest — frontend (Profile, Rewards, Team feed, Leaderboards)

Plain HTML/CSS/JS, no build step, no libraries. Open `index.html` in a browser (or use VS Code "Live Server").

```
index.html     sidebar + one empty <section> per page
css/style.css  all styling; colours from the Figma file are at the top (:root)
js/data.js     ALL mock data (user, items, players, feed) — swap for API data later
js/app.js      render functions for each page + button actions + hash routing
```

## How to work with it
- **Change what's shown** → edit `js/data.js`.
- **Change a page's layout** → find `renderProfile`, `renderRewards`, `renderFeed` or `renderLeaderboard` in `app.js`.
- **Add a button** → give it `data-action="myThing" data-id="..."` and add `myThing(id) { ... }` to `ACTIONS`. The page re-renders after every action.
- **Add a page** → add a `<section id="x" class="page" hidden>`, a nav link `href="#x"`, and `x: renderX` in `PAGES`.

## Storage
Only the things the user changes (coins, owned/equipped items, outfit colour, kudos, own posts — capped at 20) are saved in `localStorage` under `sidequest-v1`, a few KB at most. Clear it in DevTools → Application → Local Storage to reset the demo.

## Connecting a backend later
Replace the values in `DATA` with `fetch()` results before calling `render()`, and in `save()` send changes to the server instead of (or as well as) `localStorage`.
