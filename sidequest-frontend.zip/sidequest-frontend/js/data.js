/* ============================================================
   data.js — MOCK DATA
   Everything the pages show comes from this one object.
   When the backend is ready, replace these values with data
   from your API (e.g. fetch('/api/me')) and keep the same shape.
   ============================================================ */

const DATA = {
  // The logged-in player
  user: {
    id: 'alex',
    name: 'Alex Morgan',
    title: 'Knowledge seeker',
    level: 12,
    xp: 750,              // XP inside the current level
    xpToNext: 1000,       // XP needed to reach the next level
    streak: 5,            // days in a row
    hp: 80,
    maxHp: 100,
    coins: 30,            // creator coins (earned when peers approve your quests)
    cheatDays: 2,         // banked cheat days
    commitments: 3,       // progress toward the next cheat day...
    commitmentsPerDay: 5, // ...you need 5 completed commitments per cheat day
    pausedUntil: null,    // set when a cheat day is used
    questsDone: 47,
    duelsWon: 6,
    // Character customisation
    outfitColor: '#6444d8',
    owned: ['hoodie', 'dark', 'glasses'],
    equipped: { outfit: 'hoodie', hair: 'dark', extra: 'glasses' }
  },

  // Items you can buy in the Rewards shop. slot = which part of the character it changes.
  items: [
    { id: 'hoodie',  slot: 'outfit', name: 'Study hoodie',   price: 0 },
    { id: 'cape',    slot: 'outfit', name: 'Moonlight cape', price: 60 },
    { id: 'dark',    slot: 'hair',   name: 'Classic dark',   price: 0,  color: '#2d2240' },
    { id: 'lilac',   slot: 'hair',   name: 'Lilac dye',      price: 20, color: '#b9a3f2' },
    { id: 'gold',    slot: 'hair',   name: 'Sunlit gold',    price: 25, color: '#e3b347' },
    { id: 'glasses', slot: 'extra',  name: 'Round glasses',  price: 0 },
    { id: 'hat',     slot: 'extra',  name: 'Wizard hat',     price: 50 }
  ],

  outfitColors: ['#6444d8', '#e48b6a', '#6fb495'],

  // Rewards unlocked by reaching a level
  levelRoad: [
    { level: 10, reward: 'Party banner' },
    { level: 12, reward: 'Outfit colours' },
    { level: 13, reward: 'Night-sky balloon skin' },
    { level: 15, reward: 'Duel title: “Debater”' },
    { level: 20, reward: 'Golden dragon battle' }
  ],

  badges: [
    { name: '5-day streak',   desc: 'Studied 5 days in a row',     earned: true,  icon: '🔥' },
    { name: 'First duel win', desc: 'Won an XP duel',              earned: true,  icon: '⚔️' },
    { name: 'Fair judge',     desc: 'Rated 10 crew quests',        earned: true,  icon: '⚖️' },
    { name: 'Dragon slayer',  desc: 'Beat 10 dragon battles',      earned: false, icon: '🐉' },
    { name: 'Socratic mind',  desc: 'Finish a 5/5 Socrates talk',  earned: false, icon: '🏛️' },
    { name: 'Marathon',       desc: '30-day streak',               earned: false, icon: '🏃' }
  ],

  // Players for the leaderboard + team feed. group 'crew' = your private study party.
  players: [
    { id: 'mia',   name: 'Mia Chen',      level: 14, weeklyXp: 1820, totalXp: 14200, streak: 9,  group: 'crew' },
    { id: 'noah',  name: 'Noah Williams', level: 13, weeklyXp: 1600, totalXp: 12950, streak: 3,  group: 'crew' },
    { id: 'alex',  name: 'Alex Morgan',   level: 12, weeklyXp: 1450, totalXp: 11750, streak: 5,  group: 'crew' },
    { id: 'priya', name: 'Priya Shah',    level: 16, weeklyXp: 2140, totalXp: 18400, streak: 12, group: 'campus' },
    { id: 'jonas', name: 'Jonas Weber',   level: 15, weeklyXp: 1710, totalXp: 16300, streak: 7,  group: 'campus' },
    { id: 'sara',  name: 'Sara Okafor',   level: 11, weeklyXp: 1290, totalXp: 10100, streak: 4,  group: 'campus' },
    { id: 'leo',   name: 'Leo Park',      level: 9,  weeklyXp: 980,  totalXp: 7600,  streak: 1,  group: 'campus' }
  ],

  crew: { name: 'Campus crew', privacy: 'Private' },

  // Team newsfeed. type is used for the filter chips.
  feed: [
    { id: 1, who: 'mia',  type: 'quest',  text: 'completed “Recall the forgetting curve”', detail: 'Dragon battle · Psychology', xp: '+60 XP', time: '25 min ago', likes: 2 },
    { id: 2, who: 'alex', type: 'rating', text: 'got “Finish problem set” approved by 2 / 2 peers', detail: 'Peer difficulty 4/5', xp: '+30 coins', time: '1 h ago', likes: 1 },
    { id: 3, who: 'noah', type: 'quest',  text: 'created a crew quest “Practice biology diagrams”', detail: 'Balloon barrage · Biology · 25 min', xp: '', time: '3 h ago', likes: 3 },
    { id: 4, who: 'alex', type: 'duel',   text: 'won a Battle of wits against Mia', detail: 'XP duel · 5 rounds', xp: '+40 XP', time: '5 h ago', likes: 4 },
    { id: 5, who: 'mia',  type: 'level',  text: 'reached Level 14', detail: 'Knowledge seeker', xp: '', time: 'Yesterday', likes: 5 },
    { id: 6, who: 'noah', type: 'quest',  text: 'completed “Review flashcards”', detail: 'Balloon barrage · Biology', xp: '+50 XP', time: 'Yesterday', likes: 1 }
  ],

  // Filled in by the app (and saved in localStorage)
  myPosts: [],  // updates the user writes in the feed
  liked: []     // ids of feed posts the user gave kudos to
};
