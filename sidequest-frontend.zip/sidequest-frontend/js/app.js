/* ============================================================
   app.js — renders the 4 pages: Profile, Rewards, Team feed, Leaderboards

   How it works:
   1. data.js defines DATA (mock data).
   2. load() restores the few things the user changed (localStorage).
   3. Each page has a renderX() function that builds HTML with template
      strings and puts it into its <section>.
   4. The URL hash (#profile, #rewards, ...) decides which page is shown.
   5. Buttons have data-action="..." and are handled in ONE click listener
      at the bottom (ACTIONS object). After an action we re-render the page.
   ============================================================ */

const STORAGE_KEY = 'sidequest-v1';

// Temporary UI choices (which tab/filter is selected). Not saved.
const ui = { charTab: 'outfit', shopFilter: 'all', feedFilter: 'all', lbScope: 'crew', lbPeriod: 'weeklyXp' };

/* ---------- Saving: only small, user-changed data is stored ---------- */
function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      user: DATA.user,
      myPosts: DATA.myPosts.slice(0, 20), // cap so storage never grows forever
      liked: DATA.liked
    }));
  } catch (e) { /* storage blocked (private mode) — app still works */ }
}

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!saved) return;
    Object.assign(DATA.user, saved.user);
    DATA.myPosts = saved.myPosts || [];
    DATA.liked = saved.liked || [];
  } catch (e) { /* ignore broken data */ }
}

/* ---------- Small helpers ---------- */
const $ = (selector) => document.querySelector(selector);

// Always escape text the user typed before putting it into innerHTML
function esc(text) {
  return String(text).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function player(id) { return DATA.players.find(p => p.id === id); }
function item(id) { return DATA.items.find(i => i.id === id); }

function bar(value, max, style = '') {
  const pct = Math.min(100, Math.round(value / max * 100));
  return `<div class="bar ${style}"><span style="width:${pct}%"></span></div>`;
}

// Coloured circle with initials, e.g. "MC" for Mia Chen
const FACE_COLORS = ['#6444d8', '#e48b6a', '#6fb495', '#d0679a', '#4a90c2', '#c0952b', '#8a6fd1'];
function face(id) {
  const p = player(id);
  const initials = p.name.split(' ').map(w => w[0]).join('');
  const color = FACE_COLORS[DATA.players.indexOf(p) % FACE_COLORS.length];
  return `<div class="face" style="background:${color}">${initials}</div>`;
}

function toast(message) {
  const el = $('#toast');
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 2200);
}

/* ---------- The character, drawn as a small SVG ----------
   look = { outfit, hair, extra, color }. Change these and the drawing changes. */
function avatarSVG(look) {
  const hairColor = item(look.hair).color;
  return `
  <svg class="avatar" viewBox="0 0 120 140" aria-label="Your character">
    ${look.outfit === 'cape' ? '<path d="M28 80 Q60 66 92 80 L106 138 L14 138Z" fill="#2b2f6b"/><circle cx="96" cy="124" r="5" fill="#f4e7a1"/>' : ''}
    <rect x="34" y="74" width="52" height="64" rx="20" fill="${look.color}"/>
    <path d="M52 80 v14 M68 80 v14" stroke="#fff" stroke-width="2" opacity=".6"/>
    <circle cx="60" cy="48" r="24" fill="#9a6440"/>
    <path d="M35 47 Q33 19 60 19 Q87 19 85 47 Q80 33 69 33 Q60 28 50 33 Q40 34 35 47Z" fill="${hairColor}"/>
    <circle cx="51" cy="50" r="2.5" fill="#222"/><circle cx="69" cy="50" r="2.5" fill="#222"/>
    <path d="M53 60 Q60 65 67 60" stroke="#222" stroke-width="2" fill="none" stroke-linecap="round"/>
    ${look.extra === 'glasses' ? '<g stroke="#222" stroke-width="2" fill="none"><circle cx="51" cy="50" r="7"/><circle cx="69" cy="50" r="7"/><path d="M58 50 h4"/></g>' : ''}
    ${look.extra === 'hat' ? '<path d="M30 32 L90 32 L62 2Z" fill="#4b2f9e"/><circle cx="62" cy="18" r="3" fill="#f4e7a1"/>' : ''}
  </svg>`;
}

// The user's current look
function myLook() {
  const u = DATA.user;
  return { ...u.equipped, color: u.outfitColor };
}

/* ============================================================
   PAGE 1 — PROFILE
   ============================================================ */
function renderProfile() {
  const u = DATA.user;
  const myActivity = allPosts().filter(p => p.who === u.id).slice(0, 3);

  $('#profile').innerHTML = `
    <div class="page-head">
      <div>
        <h1>${esc(u.name)}</h1>
        <p class="muted">A little wiser. A little stronger.</p>
      </div>
      <a class="btn light" href="#rewards" style="text-decoration:none">Open rewards</a>
    </div>

    <div class="grid-2">
      <div class="stack">
        ${heroCard()}

        <div class="stats">
          ${statCard('Weekly XP', player(u.id).weeklyXp.toLocaleString())}
          ${statCard('Quests done', u.questsDone)}
          ${statCard('Duels won', u.duelsWon)}
          ${statCard('Creator coins', u.coins)}
        </div>

        <div class="card">
          <div class="spread"><h3>Badges</h3><a class="small" href="#rewards">See all</a></div>
          <div class="badges">${DATA.badges.filter(b => b.earned).map(badgeHTML).join('')}</div>
        </div>

        <div class="card">
          <h3>Recent activity</h3>
          ${myActivity.map(postHTML).join('') || '<p class="muted">Nothing yet — go complete a quest!</p>'}
        </div>
      </div>

      <div class="stack">
        ${characterCard()}
        ${hpCard()}
      </div>
    </div>`;
}

function heroCard() {
  const u = DATA.user;
  return `
    <div class="card dark">
      <div class="row" style="margin-bottom:16px">
        <div class="lvl"><small>LVL</small>${u.level}</div>
        <div>
          <div class="hero-title">${esc(u.title)}</div>
          <p class="muted">Level ${u.level + 1} unlocks: ${nextUnlock()}</p>
        </div>
      </div>
      <div class="spread small" style="margin-bottom:6px">
        <b>${u.xp.toLocaleString()} / ${u.xpToNext.toLocaleString()} XP</b><span>Level ${u.level + 1}</span>
      </div>
      ${bar(u.xp, u.xpToNext, 'lime')}
      <div class="spread small" style="margin-top:10px">
        <span style="color:var(--lime)">🔥 ${u.streak}-day streak</span>
        <span class="muted">${u.xpToNext - u.xp} XP to your next unlock</span>
      </div>
    </div>`;
}

function statCard(label, value) {
  return `<div class="card stat"><b>${value}</b><span class="muted small">${label}</span></div>`;
}

function characterCard() {
  const u = DATA.user;
  const ownedInSlot = DATA.items.filter(i => i.slot === ui.charTab && u.owned.includes(i.id));
  return `
    <div class="card">
      <div class="spread"><h3>Your character</h3><span class="tag">Equipped</span></div>
      <div class="avatar-box">${avatarSVG(myLook())}</div>

      <div class="tabs">
        ${['outfit', 'hair', 'extra'].map(slot => `
          <button class="chip ${ui.charTab === slot ? 'on' : ''}" data-action="charTab" data-id="${slot}">
            ${slot === 'extra' ? 'Extras' : slot[0].toUpperCase() + slot.slice(1)}
          </button>`).join('')}
      </div>

      <div class="chips">
        ${ownedInSlot.map(i => `
          <button class="chip ${u.equipped[i.slot] === i.id ? 'on' : ''}" data-action="equip" data-id="${i.id}">${i.name}</button>
        `).join('')}
      </div>

      <div class="spread" style="margin-bottom:14px">
        <span class="muted small">Outfit colour</span>
        <div class="row" style="gap:8px">
          ${DATA.outfitColors.map(c => `
            <button class="swatch ${u.outfitColor === c ? 'on' : ''}" style="background:${c}"
              data-action="setColor" data-id="${c}" aria-label="Colour ${c}"></button>`).join('')}
        </div>
      </div>
      <a class="btn block" href="#rewards" style="display:block;text-align:center;text-decoration:none">Get more looks</a>
    </div>`;
}

// HP + cheat days strip (same idea as the bottom-right card in the Figma "Today" page)
function hpCard() {
  const u = DATA.user;
  const paused = u.pausedUntil && u.pausedUntil > Date.now();
  return `
    <div class="card hp">
      <div class="spread small" style="margin-bottom:6px">
        <b>${u.hp} / ${u.maxHp} HP</b><b>${u.cheatDays} cheat days banked</b>
      </div>
      ${bar(u.hp, u.maxHp, 'green')}
      <p class="small muted" style="margin:10px 0">
        ${u.commitments} / ${u.commitmentsPerDay} commitments toward your next cheat day.
        Missed signed-up deadlines cost 20 HP.
      </p>
      ${paused
        ? `<p class="small"><b>⏸ Deadlines paused until ${new Date(u.pausedUntil).toLocaleString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' })}</b></p>`
        : `<button class="btn white block" data-action="useCheatDay" ${u.cheatDays ? '' : 'disabled'}>Use cheat day · Pause 24h</button>`}
    </div>`;
}

function badgeHTML(b) {
  return `
    <div class="badge ${b.earned ? '' : 'locked'}" title="${b.desc}">
      <div class="icon">${b.icon}</div>
      <b class="small">${b.name}</b>
      <p class="small muted">${b.desc}</p>
    </div>`;
}

function nextUnlock() {
  const next = DATA.levelRoad.find(r => r.level > DATA.user.level);
  return next ? next.reward : 'more to come';
}

/* ============================================================
   PAGE 2 — REWARDS
   ============================================================ */
function renderRewards() {
  const u = DATA.user;
  const items = DATA.items.filter(i => ui.shopFilter === 'all' || i.slot === ui.shopFilter);

  $('#rewards').innerHTML = `
    <div class="page-head">
      <div>
        <h1>Rewards</h1>
        <p class="muted">Spend creator coins on looks. Keep commitments to earn cheat days.</p>
      </div>
    </div>

    <div class="grid-3" style="margin-bottom:20px">
      <div class="card dark">
        <p class="muted small">Creator coins</p>
        <div class="hero-title" style="font-size:30px">🪙 ${u.coins}</div>
        <p class="muted small">Earned when peers approve quests you create.</p>
      </div>
      <div class="card hp">
        <p class="muted small">Cheat days</p>
        <div class="hero-title" style="font-size:30px">${u.cheatDays} banked</div>
        <p class="small muted" style="margin:6px 0">${u.commitments} / ${u.commitmentsPerDay} toward the next one</p>
        ${bar(u.commitments, u.commitmentsPerDay, 'green')}
      </div>
      <div class="card soft">
        <p class="muted small">Next level unlock</p>
        <div class="hero-title">${nextUnlock()}</div>
        <p class="small muted" style="margin:6px 0">${u.xpToNext - u.xp} XP to go</p>
        ${bar(u.xp, u.xpToNext)}
      </div>
    </div>

    <div class="card" style="margin-bottom:20px">
      <div class="spread"><h2>Character shop</h2></div>
      <div class="chips">
        ${[['all', 'All'], ['outfit', 'Outfits'], ['hair', 'Hair'], ['extra', 'Extras']].map(([key, label]) => `
          <button class="chip ${ui.shopFilter === key ? 'on' : ''}" data-action="shopFilter" data-id="${key}">${label}</button>`).join('')}
      </div>
      <div class="shop">${items.map(shopItemHTML).join('')}</div>
    </div>

    <div class="card" style="margin-bottom:20px">
      <h2>Level road</h2>
      <div class="road">
        ${DATA.levelRoad.map(r => {
          const done = r.level <= u.level;
          const isNext = r.level === DATA.levelRoad.find(x => x.level > u.level)?.level;
          return `<div class="road-step ${done ? 'done' : ''} ${isNext ? 'next' : ''}">
            <b>Level ${r.level}</b>${done ? '✓ ' : ''}${r.reward}</div>`;
        }).join('')}
      </div>
    </div>

    <div class="card">
      <h2>Badges</h2>
      <div class="badges">${DATA.badges.map(badgeHTML).join('')}</div>
    </div>`;
}

function shopItemHTML(i) {
  const u = DATA.user;
  const owned = u.owned.includes(i.id);
  const equipped = u.equipped[i.slot] === i.id;
  // Preview = your character wearing this item
  const preview = avatarSVG({ ...myLook(), [i.slot]: i.id });

  let button;
  if (equipped) button = `<button class="btn light block" disabled>Equipped</button>`;
  else if (owned) button = `<button class="btn light block" data-action="equip" data-id="${i.id}">Equip</button>`;
  else if (u.coins >= i.price) button = `<button class="btn block" data-action="buy" data-id="${i.id}">Buy · ${i.price} coins</button>`;
  else button = `${bar(u.coins, i.price)}<button class="btn block" disabled>${u.coins} / ${i.price} coins</button>`;

  return `
    <div class="item ${equipped ? 'equipped' : ''}">
      ${preview}
      <div class="spread"><b>${i.name}</b><span class="tag">${i.slot}</span></div>
      ${button}
    </div>`;
}

/* ============================================================
   PAGE 3 — TEAM NEWSFEED
   ============================================================ */
function allPosts() {
  return [...DATA.myPosts, ...DATA.feed]; // newest (user's own) first
}

function renderFeed() {
  const crew = DATA.players.filter(p => p.group === 'crew');
  const posts = allPosts().filter(p => ui.feedFilter === 'all' || p.type === ui.feedFilter);

  $('#feed').innerHTML = `
    <div class="page-head">
      <div>
        <h1>${DATA.crew.name}</h1>
        <p class="muted">${crew.length} members · ${DATA.crew.privacy} · see what your party is up to</p>
      </div>
    </div>

    <div class="grid-2">
      <div class="stack">
        <form class="card composer" id="post-form">
          <textarea id="post-text" maxlength="200" placeholder="Share a win, ask for a study buddy, cheer someone on…"></textarea>
          <div class="spread">
            <span class="muted small">Only your crew can see this.</span>
            <button class="btn" type="submit">Post</button>
          </div>
        </form>

        <div>
          <div class="chips">
            ${[['all', 'All'], ['quest', 'Quests'], ['duel', 'Duels'], ['rating', 'Peer ratings'], ['level', 'Level ups'], ['post', 'Updates']].map(([key, label]) => `
              <button class="chip ${ui.feedFilter === key ? 'on' : ''}" data-action="feedFilter" data-id="${key}">${label}</button>`).join('')}
          </div>
          <div class="card">
            ${posts.map(postHTML).join('') || '<p class="muted">No posts here yet.</p>'}
          </div>
        </div>
      </div>

      <div class="stack">
        <div class="card">
          <div class="spread"><h3>Party members</h3><span class="muted small">THIS WEEK</span></div>
          ${crew.map(p => `
            <div class="spread" style="margin-bottom:12px">
              <div class="row">${face(p.id)}
                <div><b>${p.id === DATA.user.id ? 'You' : p.name}</b><div class="muted small">Lvl ${p.level} · 🔥 ${p.streak}</div></div>
              </div>
              ${p.id === DATA.user.id
                ? `<span class="xp">${p.weeklyXp.toLocaleString()} XP</span>`
                : `<button class="btn light" data-action="duel" data-id="${p.id}">Duel</button>`}
            </div>`).join('')}
          <a class="btn light block" href="#leaderboard" style="display:block;text-align:center;text-decoration:none">View leaderboard</a>
        </div>
      </div>
    </div>`;
}

const TYPE_LABELS = { quest: 'Quest', duel: 'Duel', rating: 'Peer rating', level: 'Level up', post: 'Update' };

function postHTML(p) {
  const who = player(p.who);
  const liked = DATA.liked.includes(p.id);
  const likes = (p.likes || 0) + (liked ? 1 : 0);
  return `
    <div class="post">
      ${face(p.who)}
      <div class="post-body">
        <div class="spread">
          <div><b>${p.who === DATA.user.id ? 'You' : who.name}</b> ${esc(p.text)}</div>
          ${p.xp ? `<span class="xp">${p.xp}</span>` : ''}
        </div>
        ${p.detail ? `<p class="muted small" style="margin-top:2px">${esc(p.detail)}</p>` : ''}
        <div class="row small" style="margin-top:8px">
          <span class="tag">${TYPE_LABELS[p.type]}</span>
          <span class="muted">${p.time}</span>
          <button class="kudos ${liked ? 'on' : ''}" data-action="like" data-id="${p.id}">👏 ${likes}</button>
        </div>
      </div>
    </div>`;
}

/* ============================================================
   PAGE 4 — LEADERBOARDS
   ============================================================ */
function renderLeaderboard() {
  const key = ui.lbPeriod; // 'weeklyXp' or 'totalXp'
  const list = DATA.players
    .filter(p => ui.lbScope === 'all' || p.group === 'crew')
    .sort((a, b) => b[key] - a[key]);

  const myIndex = list.findIndex(p => p.id === DATA.user.id);
  const ahead = list[myIndex - 1];
  const message = ahead
    ? `Just ${(ahead[key] - list[myIndex][key]).toLocaleString()} XP from #${myIndex} place. You've got this.`
    : `You're #1. Defend your spot!`;

  const medals = ['🥇', '🥈', '🥉'];
  const top3 = list.slice(0, 3);
  const podiumOrder = [top3[1], top3[0], top3[2]].filter(Boolean); // 2nd, 1st, 3rd

  $('#leaderboard').innerHTML = `
    <div class="page-head">
      <div>
        <h1>Leaderboards</h1>
        <p class="muted">Compare your effort, not your grades. XP follows real difficulty and effort.</p>
      </div>
    </div>

    <div class="spread" style="flex-wrap:wrap">
      <div class="chips">
        <button class="chip ${ui.lbScope === 'crew' ? 'on' : ''}" data-action="lbScope" data-id="crew">Campus crew</button>
        <button class="chip ${ui.lbScope === 'all' ? 'on' : ''}" data-action="lbScope" data-id="all">Whole campus</button>
      </div>
      <div class="chips">
        <button class="chip ${key === 'weeklyXp' ? 'on' : ''}" data-action="lbPeriod" data-id="weeklyXp">This week</button>
        <button class="chip ${key === 'totalXp' ? 'on' : ''}" data-action="lbPeriod" data-id="totalXp">All time</button>
      </div>
    </div>

    <div class="podium">
      ${podiumOrder.map(p => {
        const rank = list.indexOf(p);
        return `
          <div class="card ${rank === 0 ? 'first' : ''}">
            <div class="medal">${medals[rank]}</div>
            ${face(p.id)}
            <b>${p.id === DATA.user.id ? 'You' : p.name}</b>
            <div class="xp">${p[key].toLocaleString()} XP</div>
          </div>`;
      }).join('')}
    </div>

    <div class="card soft" style="margin-bottom:20px">📈 ${message}</div>

    <div class="card">
      ${list.map((p, i) => `
        <div class="lb-row ${p.id === DATA.user.id ? 'you' : ''}">
          <span class="lb-rank">${String(i + 1).padStart(2, '0')}</span>
          ${face(p.id)}
          <span>${p.id === DATA.user.id ? 'You' : p.name}</span>
          <span class="muted small hide-sm">Lvl ${p.level} · 🔥 ${p.streak}</span>
          <span class="xp" style="text-align:right">${p[key].toLocaleString()} XP</span>
        </div>`).join('')}
    </div>`;
}

/* ============================================================
   ACTIONS — what each data-action button does
   ============================================================ */
const ACTIONS = {
  charTab(slot) { ui.charTab = slot; },
  shopFilter(slot) { ui.shopFilter = slot; },
  feedFilter(type) { ui.feedFilter = type; },
  lbScope(scope) { ui.lbScope = scope; },
  lbPeriod(period) { ui.lbPeriod = period; },

  setColor(color) { DATA.user.outfitColor = color; save(); },

  equip(id) {
    const it = item(id);
    const eq = DATA.user.equipped;
    // Clicking an equipped extra takes it off; outfit/hair always need something
    eq[it.slot] = (it.slot === 'extra' && eq.extra === id) ? null : id;
    save();
  },

  buy(id) {
    const it = item(id);
    const u = DATA.user;
    if (u.coins < it.price || u.owned.includes(id)) return;
    u.coins -= it.price;
    u.owned.push(id);
    u.equipped[it.slot] = id;
    save();
    toast(`Unlocked ${it.name}! 🎉`);
  },

  useCheatDay() {
    const u = DATA.user;
    if (!u.cheatDays) return;
    u.cheatDays -= 1;
    u.pausedUntil = Date.now() + 24 * 60 * 60 * 1000;
    save();
    toast('Deadlines paused for 24h. Rest up!');
  },

  like(id) {
    id = Number(id);
    const i = DATA.liked.indexOf(id);
    if (i === -1) DATA.liked.push(id); else DATA.liked.splice(i, 1);
    save();
  },

  duel(id) { toast(`Duel request sent to ${player(id).name} ⚔️`); }
};

// One listener for every button on every page ("event delegation")
document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn || btn.disabled) return;
  ACTIONS[btn.dataset.action](btn.dataset.id);
  render();
});

// Posting an update in the team feed
document.addEventListener('submit', (e) => {
  if (e.target.id !== 'post-form') return;
  e.preventDefault();
  const text = $('#post-text').value.trim();
  if (!text) return;
  DATA.myPosts.unshift({ id: Date.now(), who: DATA.user.id, type: 'post', text: `posted: “${text}”`, time: 'Just now', likes: 0 });
  save();
  render();
});

/* ============================================================
   ROUTING — show the page that matches the URL hash
   ============================================================ */
const PAGES = { profile: renderProfile, rewards: renderRewards, feed: renderFeed, leaderboard: renderLeaderboard };

function currentPage() {
  const name = location.hash.slice(1);
  return PAGES[name] ? name : 'profile';
}

function render() {
  const page = currentPage();
  document.querySelectorAll('.page').forEach(s => { s.hidden = s.id !== page; });
  document.querySelectorAll('.nav a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + page));
  $('#sidebar-me').innerHTML = `<b>${esc(DATA.user.name)}</b><span class="muted small">${esc(DATA.user.title)} · Level ${DATA.user.level}</span>`;
  PAGES[page]();
}

window.addEventListener('hashchange', () => { render(); window.scrollTo(0, 0); });

load();
render();
