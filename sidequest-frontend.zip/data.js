/* =========================================================
   data.js  –  MOCK DATA
   ---------------------------------------------------------
   Everything the app shows comes from these plain objects.
   Later, your backend team can replace these with data
   fetched from an API (see README.md, "Plugging in a backend").
   ========================================================= */

// The logged-in user. xp is the main number we track;
// level and progress are calculated from it in app.js.
const currentUser = {
  id: 1,
  name: "Alex Morgan",
  title: "Knowledge seeker",
  xp: 560,              // total XP ever earned
  weekXp: 180,          // XP earned this week (for the weekly leaderboard)
  streakDays: 5,        // days in a row with at least one quest done
  hp: 80,               // health: missed deadlines cost 20 HP
  cheatDays: 2,         // tokens that pause deadlines for 24 h
  commitments: 3,       // finished commitments toward the next cheat day (5 = +1 day)
  coins: 30,            // creator coins, earned when peers approve your quests
  equippedSkin: "violet",
  hair: "dark",
  extras: { glasses: true, backpack: false },
  doneTasks: ["flash"]  // ids of today's quests that are finished
};

// Today's quests. Ticking one off gives its XP.
// icon = the little game picture, game = the quest style from the design.
const tasks = [
  { id: "recall",  label: "Recall the forgetting curve", icon: "🐉", game: "Dragon battle",   subject: "Psychology",  minutes: 25, xp: 60,  difficulty: "3/5 · Medium",
    deadline: "Today, 18:00", penalty: "Miss deadline: −20 HP to you; dragon regains up to 20 HP." },
  { id: "probset", label: "Finish problem set",          icon: "🧩", game: "Labyrinth",       subject: "Mathematics", minutes: 40, xp: 120, difficulty: "4/5 · Hard",
    deadline: "Today, 18:00", penalty: "Wrong turn: +00:30. Missed deadline: −20 HP." },
  { id: "flash",   label: "Review flashcards",           icon: "🎈", game: "Balloon barrage", subject: "Biology",     minutes: 15, xp: 50,  difficulty: "2/5 · Easy",
    deadline: "Today, 12:00", penalty: "Missed deadline: −20 HP, the wave restarts." }
];

// Outfits (hoodie colours) and badges. "unlockLevel" decides when each one is available.
const rewards = [
  { id: "violet", type: "skin",  name: "Violet hoodie",   color: "#7c5cff", unlockLevel: 1 },
  { id: "peach",  type: "skin",  name: "Peach hoodie",    color: "#e8957a", unlockLevel: 2 },
  { id: "sage",   type: "skin",  name: "Sage hoodie",     color: "#7fb59a", unlockLevel: 3 },
  { id: "night",  type: "skin",  name: "Midnight hoodie", color: "#35224d", unlockLevel: 5 },
  { id: "gold",   type: "skin",  name: "Legend gold",     color: "#d9a520", unlockLevel: 7 },
  { id: "first",  type: "badge", name: "First quest",     icon: "🏅", unlockLevel: 1 },
  { id: "streak", type: "badge", name: "5-day streak",    icon: "🔥", unlockLevel: 3 },
  { id: "owl",    type: "badge", name: "Night owl",       icon: "🦉", unlockLevel: 4 },
  { id: "dragon", type: "badge", name: "Dragon slayer",   icon: "🐉", unlockLevel: 5 },
  { id: "raid",   type: "badge", name: "Party raider",    icon: "⚔️", unlockLevel: 6 }
];

// Hair colours for the "Hair" tab of the character card (all free).
const hairColors = { dark: "#2b2340", brown: "#7a4a2a", blonde: "#e0b85c", pink: "#e27fb0" };

// Other members of the study party (for leaderboard and feed).
const teammates = [
  { id: 2, name: "Mia Chen",      xp: 820, weekXp: 260, skin: "night" },
  { id: 3, name: "Noah Williams", xp: 700, weekXp: 210, skin: "peach" },
  { id: 4, name: "Lena Fischer",  xp: 610, weekXp: 120, skin: "sage" },
  { id: 5, name: "Jonas Weber",   xp: 430, weekXp: 150, skin: "peach" },
  { id: 6, name: "Aylin Kaya",    xp: 300, weekXp: 90,  skin: "violet" },
  { id: 7, name: "Tom Becker",    xp: 150, weekXp: 40,  skin: "peach" },
  { id: 8, name: "Sara Novak",    xp: 95,  weekXp: 95,  skin: "violet" }
];

// Quests shared with the party. Peers rate them; XP is final after 2 ratings.
// status: "needs-rating" (you still have to rate it) or "reviewed"
const sharedQuests = [
  { id: "spaced", title: "Explain spaced repetition", icon: "🧙", game: "Socrates",        subject: "Psychology",  minutes: 35, creator: "Mia Chen",
    demand: "Hard 4/5", status: "needs-rating", ratings: 1, xp: null,
    description: "Socrates only asks questions and continues until the reasoning is accurate enough. Harder demands require more time; the source stays private." },
  { id: "probset", title: "Finish problem set",        icon: "🧩", game: "Recall labyrinth", subject: "Mathematics", minutes: 40, creator: "Alex Morgan",
    demand: "Peer 4/5", status: "reviewed", ratings: 2, xp: 120, usefulness: 5.0,
    description: "Explore only the path ahead; answer questions 1–8 to choose directions, then share your working." },
  { id: "biology", title: "Practice biology diagrams", icon: "🎈", game: "Balloon barrage",  subject: "Biology",     minutes: 25, creator: "Noah Williams",
    demand: "Peer 2/5", status: "reviewed", ratings: 2, xp: 60, usefulness: 4.0,
    description: "Shoot balloons with correct biology answers, then draw a cell from memory and check your work." }
];

// Starting posts for the party feed (newest first).
// type picks the little icon: "quest", "level", "unlock", "streak", "rating"
const feed = [
  { user: "Mia Chen",      type: "level",  text: "reached Level 5",                    time: "10 min ago" },
  { user: "Noah Williams", type: "quest",  text: "finished Practice biology diagrams", xp: 60, time: "32 min ago" },
  { user: "Lena Fischer",  type: "unlock", text: "unlocked the Sage hoodie",           time: "1 h ago" },
  { user: "Jonas Weber",   type: "streak", text: "is on a 7-day streak",               time: "3 h ago" }
];
